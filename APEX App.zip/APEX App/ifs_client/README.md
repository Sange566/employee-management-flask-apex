# TechInnovators Inventory Client (Flask)

## Purpose
Professional Flask client to test Oracle APEX REST endpoints with enhanced UI/UX:
- GET bookings: `/get_date_data?empid=...`
- POST return: `/postdata?returndate=YYYY-MM-DD&bookid=...&empid=...`

Includes a mock mode for demo if the ORDS endpoint is unavailable.

## Features
- 🔐 **Authentication**: Flask-Login integration with secure password hashing
- 📱 **QR Code Login**: Scan QR codes to login with employee ID or username
- 🔍 **QR Return Verification**: Scan employee QR codes to verify equipment returns
- 🎨 **Modern UI**: Bootstrap 5 with custom styling and responsive design
- 📱 **Mobile-First**: Responsive layout optimized for all devices
- ✅ **Form Validation**: Client-side validation with real-time feedback
- 📅 **Date Picker**: Flatpickr integration for return date selection
- 🔄 **Loading States**: Spinner overlays and progress indicators
- 🎯 **Toast Notifications**: Bootstrap toast system for user feedback
- 🎭 **Mock Mode**: Demo mode with sample data when ORDS unavailable
- 📱 **QR Codes**: Generate QR codes for equipment bookings and login
- ♿ **Accessibility**: ARIA labels, semantic HTML, and keyboard navigation

## Files
- `app.py` - main Flask application with enhanced debugging
- `templates/` - Enhanced HTML templates with modern design
- `static/style.css` - Comprehensive CSS styling and animations
- `static/app.js` - JavaScript for interactivity and validation
- `.env.example` - environment variables template

## Quick Start (Windows PowerShell)

### 1. Install Dependencies
```powershell
# Navigate to project directory
cd ifs_client

# Install required packages
pip install -r requirements.txt
```

### 2. Configure Environment
```powershell
# Copy environment template
Copy-Item .env.example .env

# Edit .env file to set your APEX endpoint
# BASE_URL=https://your-apex-endpoint.com/ords/...
# MOCK=1  # Set to 1 for demo mode
# FLASK_DEBUG=1
```

### 3. Run with Mock Mode (Recommended for Demo)
```powershell
# Set mock mode for current session
$env:MOCK = "1"

# Start the application
python app.py
```

### 4. Run with Real APEX Endpoints
```powershell
# Set real endpoint and disable mock
$env:BASE_URL = "https://your-apex-endpoint.com/ords/..."
$env:MOCK = "0"

# Start the application
python app.py
```

## Usage

### Authentication
- **Traditional Login**: Use the demo credentials to access the system
  - Username: `admin`
  - Password: `password123`
- **QR Code Login**: Scan a QR code containing `empid=1` or `empid=2`
  - Click "Scan QR Code" button on login page
  - Allow camera permissions when prompted
  - Scan the QR code displayed on the login page or generate your own
- **Logout**: Click on your username in the navbar and select "Logout"

### Main Features
1. **View Bookings**: Enter employee ID to fetch equipment bookings
2. **Return Equipment**: Use the Quick Return form or click Return buttons in the table
3. **QR Return Verification**: Scan employee QR codes to verify equipment returns
4. **QR Codes**: Click the QR code icon next to any booking to generate a QR code
5. **Dashboard**: View current vs historical bookings with statistics
6. **Mock Mode**: When enabled, shows sample data for demonstration

### Testing QR Codes
- **Booking QR Codes**: Visit `/qrcode/1` to see a sample QR code for booking ID 1
- **Login QR Codes**: Visit `/login-qrcode/1` to see a login QR code for employee ID 1
- QR codes contain booking details and can be scanned with any QR reader
- QR codes are generated as PNG images and can be saved/printed

### QR Code Login Testing
1. **Generate Login QR Code**: Visit `/login-qrcode/1` to get a QR code for employee 1
2. **Test Scanning**: 
   - Go to the login page
   - Click "Scan QR Code" button
   - Allow camera permissions
   - Scan the QR code from step 1
   - You should be automatically logged in and redirected to the home page
3. **QR Code Format**: Login QR codes contain `empid=X` where X is the employee ID
4. **Valid Employee IDs**: Currently supports `empid=1` and `empid=2` (both map to admin user)

### QR Return Verification Testing
1. **Access Bookings**: Login and view bookings for employee 1
2. **Test QR Return**: 
   - Click the QR scan icon (📱) next to any active booking
   - Allow camera permissions when prompted
   - Scan an employee QR code containing `empid=1`
   - If the QR code matches the booking's employee ID, the return will be processed
   - If it doesn't match, you'll see an error message
3. **QR Code Format**: Return verification QR codes should contain `empid=X` where X matches the booking's employee ID
4. **Security**: Only QR codes with matching employee IDs can successfully return equipment

## UI Enhancements Made
- **Layout**: Added company branding, slim topbar, and professional footer
- **Forms**: Enhanced with validation, date picker, and better mobile support
- **Tables**: Responsive design with status badges and action buttons
- **Navigation**: Improved breadcrumbs and action buttons
- **Feedback**: Toast notifications, loading spinners, and confirmation modals
- **Styling**: Modern card design, hover effects, and consistent spacing

## Files Changed
- `templates/layout.html` - Added branding, navigation, user menu, and modal structure
- `templates/index.html` - Enhanced forms with validation and better layout
- `templates/bookings.html` - Improved table design, return workflow, and QR code links
- `templates/dashboard.html` - New dashboard with tabs and QR code integration
- `templates/login.html` - New login page with Bootstrap styling
- `templates/return_result.html` - Better result display with status badges
- `static/style.css` - Comprehensive styling and responsive design
- `static/app.js` - JavaScript for validation, date picker, and UI interactions
- `app.py` - Added authentication, QR code generation, and enhanced debugging
- `requirements.txt` - Added Flask-Login and qrcode dependencies

## Notes for Assignment
- **Mock Mode**: Set `MOCK=1` in .env for reliable demo without network dependencies
- **BASE_URL**: Ensure it points to your APEX module base path (no trailing slash)
- **Screenshots**: Include UI screenshots showing the enhanced interface
- **Testing**: Test both mock mode and real APEX endpoints if available

## Troubleshooting
- **Port Issues**: Ensure port 5000 is available or change in app.py
- **Package Issues**: Run `pip install -r requirements.txt` to install dependencies
- **Mock Mode**: Use `MOCK=1` if experiencing network or ORDS connectivity issues
- **Browser**: Modern browsers recommended for best experience
