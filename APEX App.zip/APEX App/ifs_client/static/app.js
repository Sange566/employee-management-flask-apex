// TechInnovators Inventory Client - JavaScript Functions

// Global variables
let currentToast = null;

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeDatePickers();
    initializeFormValidation();
    initializeToastHandling();
});

// Initialize Flatpickr date pickers
function initializeDatePickers() {
    const dateInputs = document.querySelectorAll('.datepicker');
    dateInputs.forEach(input => {
        flatpickr(input, {
            dateFormat: "Y-m-d",
            allowInput: true,
            placeholder: "Today (leave blank)",
            maxDate: "today",
            onChange: function(selectedDates, dateStr, instance) {
                if (dateStr) {
                    input.classList.add('is-valid');
                } else {
                    input.classList.remove('is-valid');
                }
            }
        });
    });
}

// Initialize form validation
function initializeFormValidation() {
    // View Bookings Form
    const viewBookingsForm = document.getElementById('viewBookingsForm');
    if (viewBookingsForm) {
        viewBookingsForm.addEventListener('submit', function(e) {
            const empidInput = document.getElementById('empid');
            if (!empidInput.value.trim()) {
                e.preventDefault();
                empidInput.classList.add('is-invalid');
                showToast('Please enter an Employee ID.', 'warning');
            } else {
                empidInput.classList.remove('is-invalid');
                showSpinner();
            }
        });
    }

    // Quick Return Form
    const quickReturnForm = document.getElementById('quickReturnForm');
    if (quickReturnForm) {
        quickReturnForm.addEventListener('submit', function(e) {
            const bookidInput = quickReturnForm.querySelector('input[name="bookid"]');
            const empidInput = quickReturnForm.querySelector('input[name="empid"]');
            let hasError = false;

            // Reset previous validation states
            bookidInput.classList.remove('is-invalid');
            empidInput.classList.remove('is-invalid');

            // Validate Booking ID
            if (!bookidInput.value.trim()) {
                bookidInput.classList.add('is-invalid');
                hasError = true;
            }

            // Validate Employee ID
            if (!empidInput.value.trim()) {
                empidInput.classList.add('is-invalid');
                hasError = true;
            }

            if (hasError) {
                e.preventDefault();
                showToast('Please fill in all required fields.', 'warning');
                return false;
            }

            // Show spinner before submission
            showSpinner();
        });
    }

    // Real-time validation feedback
    const inputs = document.querySelectorAll('input[required]');
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (!this.value.trim()) {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
                this.classList.add('is-valid');
            }
        });

        input.addEventListener('input', function() {
            if (this.value.trim()) {
                this.classList.remove('is-invalid');
                this.classList.add('is-valid');
            }
        });
    });
}

// Initialize toast handling
function initializeToastHandling() {
    // Auto-hide toasts after 5 seconds
    const toasts = document.querySelectorAll('.toast');
    toasts.forEach(toast => {
        setTimeout(() => {
            const bsToast = new bootstrap.Toast(toast);
            bsToast.hide();
        }, 5000);
    });
}

// Show loading spinner
function showSpinner() {
    const spinner = document.getElementById('loadingSpinner');
    if (spinner) {
        spinner.classList.remove('d-none');
    }
}

// Hide loading spinner
function hideSpinner() {
    const spinner = document.getElementById('loadingSpinner');
    if (spinner) {
        spinner.classList.add('d-none');
    }
}

// Show toast message
function showToast(message, type = 'info') {
    // Hide existing toast
    if (currentToast) {
        currentToast.hide();
    }

    // Create new toast
    const toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) return;

    const toastHtml = `
        <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-${type} text-white">
                <strong class="me-auto">
                    ${getToastIcon(type)} ${getToastTitle(type)}
                </strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>
    `;

    toastContainer.insertAdjacentHTML('beforeend', toastHtml);
    
    const newToast = toastContainer.lastElementChild;
    currentToast = new bootstrap.Toast(newToast);
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        if (currentToast) {
            currentToast.hide();
        }
    }, 5000);
}

// Get toast icon based on type
function getToastIcon(type) {
    switch(type) {
        case 'success': return '✅';
        case 'danger': return '❌';
        case 'warning': return '⚠️';
        default: return 'ℹ️';
    }
}

// Get toast title based on type
function getToastTitle(type) {
    switch(type) {
        case 'success': return 'Success';
        case 'danger': return 'Error';
        case 'warning': return 'Warning';
        default: return 'Info';
    }
}

// Utility function to format dates
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Utility function to validate employee ID format
function validateEmployeeId(empid) {
    return /^\d+$/.test(empid) && empid.length > 0;
}

// Utility function to validate booking ID format
function validateBookingId(bookid) {
    return /^\d+$/.test(bookid) && bookid.length > 0;
}

// Export functions for use in templates
window.showSpinner = showSpinner;
window.hideSpinner = hideSpinner;
window.showToast = showToast;
window.formatDate = formatDate;
window.validateEmployeeId = validateEmployeeId;
window.validateBookingId = validateBookingId;
