// Enhanced Forms with AJAX and Auto-save
class EnhancedForms {
  constructor() {
    this.autoSaveInterval = 30000; // 30 seconds
    this.autoSaveEnabled = true;
    this.formData = new Map();
    this.init();
  }

  init() {
    this.setupFormEnhancements();
    this.setupAutoSave();
    this.setupFormValidation();
    this.setupProgressIndicators();
  }

  setupFormEnhancements() {
    // Add AJAX submission to all forms
    const forms = document.querySelectorAll('form[data-ajax]');
    forms.forEach(form => {
      form.addEventListener('submit', this.handleAjaxSubmit.bind(this));
    });

    // Add auto-save to forms with data-autosave attribute
    const autoSaveForms = document.querySelectorAll('form[data-autosave]');
    autoSaveForms.forEach(form => {
      this.setupAutoSaveForForm(form);
    });

    // Add real-time validation
    const inputs = document.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
      input.addEventListener('blur', this.validateField.bind(this));
      input.addEventListener('input', this.debounce(this.validateField.bind(this), 500));
    });
  }

  setupAutoSave() {
    if (!this.autoSaveEnabled) return;

    setInterval(() => {
      this.saveAllForms();
    }, this.autoSaveInterval);

    // Save on page unload
    window.addEventListener('beforeunload', () => {
      this.saveAllForms();
    });
  }

  setupAutoSaveForForm(form) {
    const inputs = form.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
      input.addEventListener('input', this.debounce(() => {
        this.saveFormData(form);
      }, 2000));
    });
  }

  async handleAjaxSubmit(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const submitBtn = form.querySelector('[type="submit"]');
    
    // Show loading state
    this.setLoadingState(submitBtn, true);
    
    try {
      const response = await fetch(form.action || window.location.href, {
        method: form.method || 'POST',
        body: formData,
        headers: {
          'X-Requested-With': 'XMLHttpRequest'
        }
      });

      const result = await response.json();
      
      if (response.ok) {
        this.showSuccessMessage(result.message || 'Form submitted successfully!');
        this.clearFormData(form);
        
        // Redirect if specified
        if (result.redirect) {
          window.location.href = result.redirect;
        }
      } else {
        this.showErrorMessage(result.message || 'An error occurred. Please try again.');
        this.displayFieldErrors(result.errors || {});
      }
    } catch (error) {
      console.error('Form submission error:', error);
      this.showErrorMessage('Network error. Please check your connection and try again.');
    } finally {
      this.setLoadingState(submitBtn, false);
    }
  }

  async saveFormData(form) {
    const formId = form.id || form.name || 'form_' + Math.random().toString(36).substr(2, 9);
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    
    // Store in memory
    this.formData.set(formId, data);
    
    // Save to localStorage as backup
    try {
      localStorage.setItem(`form_${formId}`, JSON.stringify({
        data: data,
        timestamp: Date.now()
      }));
    } catch (error) {
      console.warn('Could not save to localStorage:', error);
    }

    // Show auto-save indicator
    this.showAutoSaveIndicator(form);
  }

  async saveAllForms() {
    const forms = document.querySelectorAll('form[data-autosave]');
    for (const form of forms) {
      await this.saveFormData(form);
    }
  }

  loadFormData(form) {
    const formId = form.id || form.name || 'form_' + Math.random().toString(36).substr(2, 9);
    
    try {
      const saved = localStorage.getItem(`form_${formId}`);
      if (saved) {
        const { data, timestamp } = JSON.parse(saved);
        
        // Check if data is not too old (24 hours)
        if (Date.now() - timestamp < 24 * 60 * 60 * 1000) {
          this.populateForm(form, data);
          this.showRestoreMessage(form);
        }
      }
    } catch (error) {
      console.warn('Could not load form data:', error);
    }
  }

  populateForm(form, data) {
    Object.entries(data).forEach(([name, value]) => {
      const field = form.querySelector(`[name="${name}"]`);
      if (field) {
        if (field.type === 'checkbox' || field.type === 'radio') {
          field.checked = value === 'on' || value === field.value;
        } else {
          field.value = value;
        }
      }
    });
  }

  clearFormData(form) {
    const formId = form.id || form.name || 'form_' + Math.random().toString(36).substr(2, 9);
    this.formData.delete(formId);
    localStorage.removeItem(`form_${formId}`);
  }

  async validateField(event) {
    const field = event.target;
    const form = field.closest('form');
    
    if (!form || !field.name) return;

    // Clear previous validation
    this.clearFieldValidation(field);

    // Basic validation
    const isValid = this.validateFieldValue(field);
    
    if (!isValid) {
      this.showFieldError(field, this.getFieldErrorMessage(field));
    } else {
      this.showFieldSuccess(field);
    }

    // Server-side validation for complex fields
    if (field.dataset.validateServer) {
      await this.validateFieldServer(field);
    }
  }

  validateFieldValue(field) {
    const value = field.value.trim();
    const type = field.type;
    const required = field.hasAttribute('required');

    if (required && !value) {
      return false;
    }

    if (value) {
      switch (type) {
        case 'email':
          return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
        case 'tel':
          return /^[\+]?[1-9][\d]{0,15}$/.test(value);
        case 'url':
          try {
            new URL(value);
            return true;
          } catch {
            return false;
          }
        case 'number':
          return !isNaN(value) && isFinite(value);
        default:
          return true;
      }
    }

    return true;
  }

  async validateFieldServer(field) {
    try {
      const response = await fetch('/validate-field', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
          field: field.name,
          value: field.value,
          form: field.closest('form').id
        })
      });

      const result = await response.json();
      
      if (!result.valid) {
        this.showFieldError(field, result.message);
      } else {
        this.showFieldSuccess(field);
      }
    } catch (error) {
      console.warn('Server validation failed:', error);
    }
  }

  getFieldErrorMessage(field) {
    const type = field.type;
    const required = field.hasAttribute('required');

    if (required && !field.value.trim()) {
      return field.dataset.requiredMessage || 'This field is required';
    }

    switch (type) {
      case 'email':
        return 'Please enter a valid email address';
      case 'tel':
        return 'Please enter a valid phone number';
      case 'url':
        return 'Please enter a valid URL';
      case 'number':
        return 'Please enter a valid number';
      default:
        return 'Please enter a valid value';
    }
  }

  showFieldError(field, message) {
    field.classList.add('is-invalid');
    field.classList.remove('is-valid');
    
    let feedback = field.parentNode.querySelector('.invalid-feedback');
    if (!feedback) {
      feedback = document.createElement('div');
      feedback.className = 'invalid-feedback';
      field.parentNode.appendChild(feedback);
    }
    feedback.textContent = message;
  }

  showFieldSuccess(field) {
    field.classList.add('is-valid');
    field.classList.remove('is-invalid');
  }

  clearFieldValidation(field) {
    field.classList.remove('is-valid', 'is-invalid');
    const feedback = field.parentNode.querySelector('.invalid-feedback');
    if (feedback) {
      feedback.remove();
    }
  }

  displayFieldErrors(errors) {
    Object.entries(errors).forEach(([fieldName, message]) => {
      const field = document.querySelector(`[name="${fieldName}"]`);
      if (field) {
        this.showFieldError(field, message);
      }
    });
  }

  setLoadingState(button, isLoading) {
    if (isLoading) {
      button.disabled = true;
      button.dataset.originalText = button.textContent;
      button.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading...';
    } else {
      button.disabled = false;
      button.textContent = button.dataset.originalText || 'Submit';
    }
  }

  showAutoSaveIndicator(form) {
    const indicator = form.querySelector('.auto-save-indicator') || this.createAutoSaveIndicator(form);
    indicator.style.display = 'block';
    indicator.textContent = 'Auto-saved';
    
    setTimeout(() => {
      indicator.style.display = 'none';
    }, 2000);
  }

  createAutoSaveIndicator(form) {
    const indicator = document.createElement('div');
    indicator.className = 'auto-save-indicator text-muted small mt-2';
    indicator.style.display = 'none';
    form.appendChild(indicator);
    return indicator;
  }

  showRestoreMessage(form) {
    const message = document.createElement('div');
    message.className = 'alert alert-info alert-dismissible fade show mt-2';
    message.innerHTML = `
      <i class="fas fa-info-circle me-2"></i>
      Form data restored from previous session.
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    form.insertBefore(message, form.firstChild);
  }

  showSuccessMessage(message) {
    this.showToast(message, 'success');
  }

  showErrorMessage(message) {
    this.showToast(message, 'error');
  }

  showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast-notification toast-${type}`;
    toast.innerHTML = `
      <div class="toast-content">
        <i class="fas fa-${this.getToastIcon(type)}"></i>
        <span>${message}</span>
      </div>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
      toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => {
        if (document.body.contains(toast)) {
          document.body.removeChild(toast);
        }
      }, 300);
    }, 3000);
  }

  getToastIcon(type) {
    const icons = {
      success: 'check-circle',
      error: 'times-circle',
      warning: 'exclamation-triangle',
      info: 'info-circle'
    };
    return icons[type] || 'info-circle';
  }

  setupFormValidation() {
    // Add custom validation rules
    this.addCustomValidationRules();
  }

  addCustomValidationRules() {
    // Email uniqueness validation
    const emailFields = document.querySelectorAll('input[type="email"][data-validate-unique]');
    emailFields.forEach(field => {
      field.addEventListener('blur', this.debounce(async () => {
        if (field.value) {
          await this.validateEmailUniqueness(field);
        }
      }, 1000));
    });

    // Password strength validation
    const passwordFields = document.querySelectorAll('input[type="password"][data-validate-strength]');
    passwordFields.forEach(field => {
      field.addEventListener('input', this.debounce(() => {
        this.validatePasswordStrength(field);
      }, 300));
    });
  }

  async validateEmailUniqueness(field) {
    try {
      const response = await fetch('/validate-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({ email: field.value })
      });

      const result = await response.json();
      
      if (!result.available) {
        this.showFieldError(field, 'This email is already registered');
      } else {
        this.showFieldSuccess(field);
      }
    } catch (error) {
      console.warn('Email validation failed:', error);
    }
  }

  validatePasswordStrength(field) {
    const password = field.value;
    const strength = this.calculatePasswordStrength(password);
    
    const strengthIndicator = field.parentNode.querySelector('.password-strength') || 
                             this.createPasswordStrengthIndicator(field);
    
    strengthIndicator.className = `password-strength strength-${strength.level}`;
    strengthIndicator.innerHTML = `
      <div class="strength-bar">
        <div class="strength-fill" style="width: ${strength.score}%"></div>
      </div>
      <small class="strength-text">${strength.text}</small>
    `;
  }

  calculatePasswordStrength(password) {
    let score = 0;
    let feedback = [];

    if (password.length >= 8) score += 20;
    else feedback.push('at least 8 characters');

    if (/[a-z]/.test(password)) score += 20;
    else feedback.push('lowercase letters');

    if (/[A-Z]/.test(password)) score += 20;
    else feedback.push('uppercase letters');

    if (/[0-9]/.test(password)) score += 20;
    else feedback.push('numbers');

    if (/[^A-Za-z0-9]/.test(password)) score += 20;
    else feedback.push('special characters');

    let level, text;
    if (score < 40) {
      level = 'weak';
      text = 'Weak password';
    } else if (score < 80) {
      level = 'medium';
      text = 'Medium strength';
    } else {
      level = 'strong';
      text = 'Strong password';
    }

    if (feedback.length > 0) {
      text += ` (needs ${feedback.join(', ')})`;
    }

    return { score, level, text };
  }

  createPasswordStrengthIndicator(field) {
    const indicator = document.createElement('div');
    indicator.className = 'password-strength mt-2';
    field.parentNode.appendChild(indicator);
    return indicator;
  }

  setupProgressIndicators() {
    // Add progress indicators to multi-step forms
    const multiStepForms = document.querySelectorAll('form[data-multistep]');
    multiStepForms.forEach(form => {
      this.setupMultiStepForm(form);
    });
  }

  setupMultiStepForm(form) {
    const steps = form.querySelectorAll('.form-step');
    const progressBar = form.querySelector('.progress-bar');
    const currentStep = parseInt(form.dataset.currentStep) || 1;
    
    if (progressBar) {
      const progress = (currentStep / steps.length) * 100;
      progressBar.style.width = `${progress}%`;
      progressBar.setAttribute('aria-valuenow', progress);
    }
  }

  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
}

// Initialize enhanced forms when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  window.enhancedForms = new EnhancedForms();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = EnhancedForms;
}
