/**
 * QR Code Scanner for Employee and Admin Login
 * Uses jsQR library for client-side QR code scanning
 */

class QRLoginScanner {
    constructor() {
        this.video = null;
        this.canvas = null;
        this.context = null;
        this.scanning = false;
        this.stream = null;
    }

    async init() {
        // Create video element
        this.video = document.createElement('video');
        this.video.style.width = '100%';
        this.video.style.height = '100%';
        this.video.style.objectFit = 'cover';
        this.video.style.borderRadius = '8px';
        this.video.autoplay = true;
        this.video.muted = true;
        this.video.playsInline = true;

        // Create canvas for QR detection
        this.canvas = document.createElement('canvas');
        this.context = this.canvas.getContext('2d');

        // Get camera stream
        try {
            this.stream = await navigator.mediaDevices.getUserMedia({
                video: { 
                    facingMode: 'environment', // Use back camera on mobile
                    width: { ideal: 640 },
                    height: { ideal: 480 }
                }
            });
            
            this.video.srcObject = this.stream;
            
            // Wait for video to be ready
            return new Promise((resolve) => {
                this.video.onloadedmetadata = () => {
                    this.video.play().then(() => {
                        console.log('Camera initialized successfully');
                        resolve(true);
                    }).catch((playError) => {
                        console.error('Error playing video:', playError);
                        this.showError('Error starting camera. Please try again.');
                        resolve(false);
                    });
                };
                
                this.video.onerror = (error) => {
                    console.error('Video error:', error);
                    this.showError('Camera error. Please check permissions and try again.');
                    resolve(false);
                };
            });
            
        } catch (error) {
            console.error('Camera access denied:', error);
            this.showError('Camera access is required for QR scanning. Please allow camera access and try again.');
            return false;
        }
    }

    startScanning(containerId, onSuccess, onError) {
        const container = document.getElementById(containerId);
        if (!container) {
            onError('Scanner container not found');
            return;
        }

        // Clear container
        container.innerHTML = '';

        // Add video element
        container.appendChild(this.video);

        // Add scanning overlay
        const overlay = document.createElement('div');
        overlay.className = 'qr-scanner-overlay';
        overlay.innerHTML = `
            <div class="qr-scanner-frame">
                <div class="qr-scanner-corners">
                    <div class="corner top-left"></div>
                    <div class="corner top-right"></div>
                    <div class="corner bottom-left"></div>
                    <div class="corner bottom-right"></div>
                </div>
                <div class="qr-scanner-text">
                    <i class="fas fa-qrcode fa-2x mb-2"></i>
                    <p>Position QR code within the frame</p>
                </div>
            </div>
        `;
        container.appendChild(overlay);

        // Ensure video is playing
        if (this.video.paused) {
            this.video.play().catch(error => {
                console.error('Error playing video:', error);
                onError('Error starting camera feed');
            });
        }

        // Start scanning loop
        this.scanning = true;
        this.scanLoop(onSuccess, onError);
    }

    scanLoop(onSuccess, onError) {
        if (!this.scanning) return;

        if (this.video.readyState === this.video.HAVE_ENOUGH_DATA) {
            // Set canvas dimensions
            this.canvas.width = this.video.videoWidth;
            this.canvas.height = this.video.videoHeight;

            // Draw video frame to canvas
            this.context.drawImage(this.video, 0, 0, this.canvas.width, this.canvas.height);

            // Get image data
            const imageData = this.context.getImageData(0, 0, this.canvas.width, this.canvas.height);

            // Scan for QR code
            const code = jsQR(imageData.data, imageData.width, imageData.height);

            if (code) {
                console.log('QR Code detected:', code.data);
                this.setScannerState('recognized');
                this.stopScanning();
                this.processQRCode(code.data, onSuccess, onError);
                return;
            } else {
                // No QR code detected - show scanning state
                this.setScannerState('scanning');
            }
        }

        // Continue scanning
        requestAnimationFrame(() => this.scanLoop(onSuccess, onError));
    }

    processQRCode(qrData, onSuccess, onError) {
        try {
            const data = JSON.parse(qrData);
            
            // Validate QR code structure
            if (!data.type || !data.timestamp) {
                throw new Error('Invalid QR code format');
            }

            // QR codes no longer expire - removed time validation for simplicity

            // Process based on type
            if (data.type === 'employee_login') {
                if (!data.employee_id || !data.username) {
                    throw new Error('Invalid employee QR code');
                }
                onSuccess({
                    type: 'employee',
                    employee_id: data.employee_id,
                    username: data.username
                });
            } else if (data.type === 'admin_login') {
                if (!data.username) {
                    throw new Error('Invalid admin QR code');
                }
                onSuccess({
                    type: 'admin',
                    username: data.username
                });
            } else {
                throw new Error('Unknown QR code type');
            }

        } catch (error) {
            console.error('QR code processing error:', error);
            onError(error.message);
        }
    }

    setScannerState(state) {
        const frame = document.querySelector('.qr-scanner-frame');
        if (frame) {
            // Remove all state classes
            frame.classList.remove('scanning', 'recognized');
            // Add new state class
            if (state) {
                frame.classList.add(state);
            }
        }
    }

    stopScanning() {
        this.scanning = false;
        this.setScannerState(null); // Remove all state classes
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
        }
    }

    showError(message) {
        // Create error display
        const errorDiv = document.createElement('div');
        errorDiv.className = 'alert alert-danger';
        errorDiv.innerHTML = `
            <i class="fas fa-exclamation-triangle me-2"></i>
            ${message}
        `;
        
        // Find container and show error
        const container = document.querySelector('.qr-scanner-container');
        if (container) {
            container.innerHTML = '';
            container.appendChild(errorDiv);
        }
    }
}

// Global scanner instance
window.qrScanner = new QRLoginScanner();
