#!/usr/bin/env python3
"""
Simple tests for TechInnovators Inventory Client API functions.
Run with: python -m pytest tests/ -v
Or: python tests/test_api_client.py
"""

import sys
import os

# Add parent directory to path to import app functions
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_mock_get_function():
    """Test the mock GET function returns expected data structure."""
    try:
        from app import mock_get
        
        # Test with employee ID 1
        result = mock_get("get_date_data", {"empid": "1"})
        
        # Verify structure
        assert "items" in result, "Response should contain 'items' key"
        assert "count" in result, "Response should contain 'count' key"
        assert result["count"] == 1, "Should return 1 item for employee 1"
        
        # Verify item structure
        if result["items"]:
            item = result["items"][0]
            assert "t_booking_id" in item, "Item should have booking ID"
            assert "t_item_name" in item, "Item should have item name"
            assert "t_employee_id" in item, "Item should have employee ID"
        
        print("✅ Mock GET function test passed")
        return True
        
    except Exception as e:
        print(f"❌ Mock GET function test failed: {e}")
        return False

def test_mock_post_function():
    """Test the mock POST function returns expected data structure."""
    try:
        from app import mock_post
        
        # Test postdata endpoint
        result = mock_post("postdata", {"bookid": "1", "empid": "1", "returndate": "2025-01-01"})
        
        # Verify structure
        assert "updated_rows" in result, "Response should contain 'updated_rows' key"
        assert "status" in result, "Response should contain 'status' key"
        assert result["status"] == "success", "Status should be 'success'"
        assert result["updated_rows"] == 1, "Should indicate 1 row updated"
        
        print("✅ Mock POST function test passed")
        return True
        
    except Exception as e:
        print(f"❌ Mock POST function test failed: {e}")
        return False

def test_mock_get_empty_employee():
    """Test mock GET function with non-existent employee returns empty result."""
    try:
        from app import mock_get
        
        # Test with employee ID 999 (non-existent)
        result = mock_get("get_date_data", {"empid": "999"})
        
        # Verify empty result
        assert "items" in result, "Response should contain 'items' key"
        assert "count" in result, "Response should contain 'count' key"
        assert result["count"] == 0, "Should return 0 items for non-existent employee"
        assert len(result["items"]) == 0, "Items array should be empty"
        
        print("✅ Mock GET empty employee test passed")
        return True
        
    except Exception as e:
        print(f"❌ Mock GET empty employee test failed: {e}")
        return False

def run_all_tests():
    """Run all tests and return results."""
    print("🧪 Running TechInnovators Inventory Client Tests...")
    print("=" * 50)
    
    tests = [
        test_mock_get_function,
        test_mock_post_function,
        test_mock_get_empty_employee
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
        print()
    
    print("=" * 50)
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed!")
        return True
    else:
        print("⚠️  Some tests failed. Check the output above.")
        return False

if __name__ == "__main__":
    # Run tests when script is executed directly
    success = run_all_tests()
    sys.exit(0 if success else 1)
